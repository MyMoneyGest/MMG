const { initializeApp } = require('firebase/app');
const { getAuth, signInWithEmailAndPassword } = require('firebase/auth');

const firebaseConfig = {
  apiKey: "AIzaSyCl2Xp-LhXewBMYXJXvM7KAyTbQj6Xevqo",
  authDomain: "mymoneygest-f14d7.firebaseapp.com",
};

const email = "patrickngouala@gmail.com";
const password = "123456";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

signInWithEmailAndPassword(auth, email, password)
  .then(async (userCredential) => {
    const token = await userCredential.user.getIdToken();
    console.log("✅ ID Token :\n", token);
  })
  .catch((error) => {
    console.error("❌ Erreur de connexion :", error.code, error.message);
  });