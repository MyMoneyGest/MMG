import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();
const db = admin.firestore();

export const processTransaction = functions.firestore
  .document('transactions/{transactionId}')
  .onCreate(async (snap, context) => {
    const data = snap.data();

    if (!data || !data.senderUid || !data.receiverUid || !data.amount) {
      console.error('Transaction data is incomplete:', data);
      return null;
    }

    const { senderUid, receiverUid, amount } = data;
    const transactionRef = snap.ref;

    const senderRef = db.doc(`users/${senderUid}/linkedAccounts/airtel`);
    const receiverRef = db.doc(`users/${receiverUid}/linkedAccounts/airtel`);

    try {
      await db.runTransaction(async (t) => {
        const senderSnap = await t.get(senderRef);
        const receiverSnap = await t.get(receiverRef);

        const senderBalance = senderSnap.data()?.airtelBalance || 0;
        const receiverBalance = receiverSnap.data()?.airtelBalance || 0;

        if (senderBalance < amount) {
          await t.update(transactionRef, { status: 'failed' });
          throw new Error('Solde insuffisant');
        }

        t.update(senderRef, {
          airtelBalance: senderBalance - amount,
          transactions: admin.firestore.FieldValue.arrayUnion({
            type: 'virement_émis',
            to: receiverUid,
            amount,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
          }),
        });

        t.update(receiverRef, {
          airtelBalance: receiverBalance + amount,
          transactions: admin.firestore.FieldValue.arrayUnion({
            type: 'virement_reçu',
            from: senderUid,
            amount,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
          }),
        });

        t.update(transactionRef, { status: 'success' });
      });
    } catch (error) {
      console.error('Erreur transaction:', error);
      await transactionRef.update({ status: 'failed' });
    }

    return null;
  });